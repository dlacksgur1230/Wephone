# WEAPON BALL ARENA

브라우저에서 실행하는 단일 HTML 웨폰볼 전투 시뮬레이터입니다.

## 실행 방법
- `index.html` 파일을 브라우저에서 열면 됩니다.

## GitHub Pages 배포
1. GitHub에서 새 저장소(repository)를 만듭니다.
2. `index.html`을 저장소 최상위(root)에 업로드합니다.
3. 저장소의 **Settings → Pages**로 이동합니다.
4. **Deploy from a branch**를 선택하고 `main` 브랜치의 `/(root)`를 지정한 뒤 저장합니다.
5. 배포가 완료되면 GitHub Pages 주소가 표시됩니다.

별도의 빌드 과정이나 패키지 설치가 필요 없는 정적 HTML 페이지입니다.
